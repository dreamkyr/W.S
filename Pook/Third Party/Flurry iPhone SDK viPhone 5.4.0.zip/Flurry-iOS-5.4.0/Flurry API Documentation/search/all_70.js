var searchData=
[
  ['pausebackgroundsession',['pauseBackgroundSession',['../interface_flurry.html#a57e18dc7c992272e3dc89e7f3bc853f4',1,'Flurry']]]
];
