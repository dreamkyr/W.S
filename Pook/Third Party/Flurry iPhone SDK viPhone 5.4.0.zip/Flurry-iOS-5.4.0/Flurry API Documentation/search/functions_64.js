var searchData=
[
  ['displayadforspace_3amodallyforviewcontroller_3a',['displayAdForSpace:modallyForViewController:',['../interface_flurry_ads.html#ae61be44f5308297f7021fef7aa702934',1,'FlurryAds']]],
  ['displayadforspace_3aonview_3aviewcontrollerforpresentation_3a',['displayAdForSpace:onView:viewControllerForPresentation:',['../interface_flurry_ads.html#a73e14f2cd53fd9e84c2a0a02c9e465ff',1,'FlurryAds']]]
];
