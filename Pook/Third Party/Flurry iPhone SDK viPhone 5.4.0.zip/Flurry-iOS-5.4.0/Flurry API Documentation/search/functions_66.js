var searchData=
[
  ['fetchadforspace_3aframe_3asize_3a',['fetchAdForSpace:frame:size:',['../interface_flurry_ads.html#a19a2ae3e9fd85ad0e21c13f5abdc0079',1,'FlurryAds']]],
  ['fetchanddisplayadforspace_3aview_3aviewcontroller_3asize_3a',['fetchAndDisplayAdForSpace:view:viewController:size:',['../interface_flurry_ads.html#ae31e43c69f271a36b4b80441b03c744f',1,'FlurryAds']]]
];
